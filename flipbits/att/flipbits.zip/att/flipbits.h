void initialize();
int guess(char S[]);
