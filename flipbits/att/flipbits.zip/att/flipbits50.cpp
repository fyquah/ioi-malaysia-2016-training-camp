#include "flipbits.h"

void initialize()
{
	
}

int guess(char S[])
{
	return 1;
}
