#include <bits/stdc++.h>
#include "flipbits.h"

using namespace std;

typedef long long ll;
typedef vector<ll> vi;
typedef pair<ll,ll> ii;
typedef pair<ll, ii> iii;
typedef long double ld;

#define fi first
#define se second
#define pb push_back
#define mp make_pair

char cc[200];

void random1(int n)
{
	for(int i = 0; i < n; i++)
	{
		cc[i] = '0' + rand()%2;
	}
}

void random2(int n)
{
	for(int i = 0; i < n; i++)
	{
		cc[i] = '0';
	}
	for(int i = 0; i < n; i++)
	{
		int x = rand()%(i+1);
		if(cc[x] == '1') cc[x] = '0';
		else cc[x] = '1';
	}
}

int main()
{
	ios_base::sync_with_stdio(0); cin.tie(0);
	srand(time(NULL));
	int cnt = 0;
	for(int i = 0; i < 100000; i++)
	{
		int r = rand()%2;
		if(r == 1) random1(200);
		else random2(200);
		if(r == 0) r = 2;
		if(guess(cc) == r) cnt++;
	}
	cout << cnt << " correct answers out of 100000 test cases." << endl;
	return 0;
}

