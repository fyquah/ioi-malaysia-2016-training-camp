#include "flipbrackets.h"

void initialize(int N, int P[], char C[])
{
	
}

void flipbrackets(int u, int v)
{
	
}

int querypath(int u, int v)
{
	return (u+v);
}
