#include "flippermutation.h"

int flip(int N, int P[])
{
	return N;
}
