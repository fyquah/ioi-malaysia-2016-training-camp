int flip(int N, int P[]);
